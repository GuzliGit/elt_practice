#!/bin/bash

CONF_FILE="/root/scripts/observer.conf"
LOG_FILE="/root/scripts/observer.log"

while read -r SCRIPT; do
	if ! pgrep -f "$SCRIPT" > /dev/null; then
		nohup "$SCRIPT" >/dev/null 2>&1 &
		echo "[$(date '+%Y-%m-%d %H:%M:%S')] Перезапущен $SCRIPT (PID $!)" >> "$LOG_FILE"
	fi
done < "$CONF_FILE"
