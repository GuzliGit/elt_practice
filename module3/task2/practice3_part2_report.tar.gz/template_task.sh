#!/bin/bash

SCRIPT_NAME=$(basename "$0")
LOG_FILE="/root/scripts/report_${SCRIPT_NAME}.log"
START_TIME=$(date '+%Y-%m-%d %H:%M:%S')
PID=$$

if [[ "$SCRIPT_NAME" == "template_task.sh" ]]; then
    echo "я бригадир, сам не работаю"
    exit 0
fi

echo "[$PID] $START_TIME Скрипт запущен" >> "$LOG_FILE"

SLEEP_TIME=$((RANDOM % 1771 + 30))
sleep "$SLEEP_TIME"

END_TIME=$(date '+%Y-%m-%d %H:%M:%S')
MINUTES=$((SLEEP_TIME / 60))

echo "[$PID] $END_TIME Скрипт завершился, работал $MINUTES минут" >> "$LOG_FILE"

